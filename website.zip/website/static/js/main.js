function myFunction() {
	var x = document.getElementById("demo");
	x.style.color = "red";
}