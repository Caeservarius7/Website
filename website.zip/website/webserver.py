from flask import Flask, request, render_template
import pymysql
app = Flask(__name__)

#dbconn = pymql.connect('3.88.19.65', 'root', 'Alpha', 'formdb')

@app.route('/')
def homepage():
	return render_template('homepage.html')

@app.route('/form')
def form():
	return render_template('form.html')

@app.route('/submit', methods=["POST","GET"])
def submit():
#	return render_template("end.html")
	if request.method=="POST":
		print(request.form)
		first_name = request.form['fname']
		last_name = request.form['lname']
		gender = request.form['gender']
		#print (first_name, last_name, gender)
		dbconn = pymysql.connect('localhost', 'root', 'Alpha', 'form')
		curs = dbconn.cursor()
		curs.execute("""INSERT INTO form values("%s", "%s", "%s")"""%(first_name, last_name, gender))
		dbconn.commit()
		dbconn.close()
		return render_template('end.html')

@app.route('/end')
def end():
	return render_template('end.html')

@app.route('/data')
def data():
	dbconn = pymysql.connect('localhost', 'root', 'Alpha', 'form')
	curs = dbconn.cursor()
	curs.execute("SELECT * FROM form")
	values = curs.fetchall()
	dbconn.close()
	print(values)
	return render_template("data.html", result=values)

if __name__ == '__main__':
	app.run('0.0.0.0',  port='80')
